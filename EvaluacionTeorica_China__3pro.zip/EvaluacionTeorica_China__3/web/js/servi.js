$(document).ready(
        function () {
            $('#tbServi').DataTable(
                    {
                        "ajax": "ConsultaServi",

                        "columns": [//Atributos que se pondrán en cada columna
                            {"data": "id"},
                            {"data": "idioma"},
                            {"data": "fecha"},
                            {"data": "comentarios"},
                            {"data": "insentivo"},

                            {"data":
                                        function (row) {
                                            var r = row['id'] + "-" + row['idioma'] + "-" + row['fecha'] + "-" + row['comentarios'] + "-" + row['insentivo']; //Acceder
                                            console.log('valor de r' + r);
                                            var botones = "<button id='btnBorrar' class='btn btn-primary btn-xs' onClick='deleteServi(" + row['id'] + ")'>Borrar</button>";
                                            botones += "<button id='btnEditar' class='btn btn-xs btn-danger' onClick='showServi(" + row['id'] + ",\"" + row['idioma'] + "\")'>Editar</button>";
                                            return botones;
                                        }
                            }
                        ]
                    });


            //valida los campos
            $('#frmServi').validate({
                rules: {
                    idioma: {
                        required: true
                    },
                    fecha: {
                        required: true
                    },
                    comentarios: {
                        required: true
                    },
                    insentivo: {
                        required: true
                    }

                },
                messages: {
                    idioma: {
                        required: "El idioma del rol es requerido"
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error');
                },
                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function (error, element) {
                    if (element.parent('.input-group'.length)) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element)
                    }
                },
                submitHandler: function (form) {
                    console.log('Formulario válido');
                    nuevoServi();
                    return false;
                }
            });

            //validar forma modal
            $('#frmServi2').validate({
                rules: {

                    idioma2: {
                        required: true
                    },
                    fecha2: {
                        required: true
                    },
                    comentarios2: {
                        required: true
                    },
                    insentivo2: {
                        required: true
                    }

                },
                messages: {
                    idioma: {
                        required: "El idioma del rol es requerido"
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error');
                },
                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function (error, element) {
                    if (element.parent('.input-group'.length)) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element)
                    }
                },
                submitHandler: function (form) {
                    console.log('Formulario modal válido');
                    updateServi();
                    return false;
                }


            });

            //cuando apareza mi showmodal guardar datos en la bd
            $('#btnEditar').on('click', function () {
                $('#frmServi2').submit();
            });

        }); // que se ejecute ya que esté listo
//FUNCIONES DEL CRUD
function deleteServi(id) {

    //Utilizando Ajax para realizar una petición al servlet que elimina personas
    $.ajax({
        url: "EliminaServi", //Url del Servlet
        type: "POST", //Método HTTP por el que se hace la petición
        data: {//Es la información que mando al servlet
            id: id
        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        Swal.fire(
                'Tu operación',
                'a sido exitosa',
                'Sigue en acción'
                );


        //Refrescando la tabla
        $('#tbServi').dataTable().api().ajax.reload();
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        Swal.fire('Algo salio Muy Mal ');

        //alert("error");
    });
}



//
function nuevoServi() {
    $.ajax({
        url: 'NuevoServi',
        type: 'POST',
        data: {
            id: $("#id").val(),
            idioma: $("#idioma").val(),
            fecha: $("#fecha").val(),
            comentarios: $("#comentarios").val(),
            insentivo: $("#insentivo").val()

        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        //alert(json.msj);
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Todo va muy bien',
            showConfirmButton: false,
            timer: 1500
        });
        //Refrescando la tabla
        $('#tbServi').dataTable().api().ajax.reload();
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Por alguna extraña razon algo salio muy mal!',
            footer: '<a href>Why do I have this issue?</a>'
        });
    });


}

function showServi(id, idioma, fecha, comentarios, insentivo) {
    $("#id2").val(id);
    $("#idioma2").val(idioma);
    $("#fecha2").val(fecha);
    $("#comentarios2").val(comentarios);
    $("#insentivo2").val(insentivo);
    $("#modalServi").modal("show");

}

function updateServi() {
    $.ajax({
        url: 'ActualizaServi',
        type: 'POST',
        data: {
            id: $("#id2").val(),
            idioma: $("#idioma2").val(),
            fecha: $("#fecha2").val(),
            comentarios: $("#comentarios2").val(),
            insentivo: $("#insentivo2").val()

        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        //alert(json.msj);
        Swal.fire({
            title: 'Operación exitosa',
            width: 600,
            padding: '3em',
            background: '#fff url(/images/trees.png)',
            backdrop: `
                          rgba(0,0,123,0.4)
                          url("/images/nyan-cat.gif")
                          center left
                          no-repeat
                        `
        })
        //Refrescando la tabla
        $('#tbServi').dataTable().api().ajax.reload();

        //Cerrando el modal
        $('#modalServi').modal("toggle");
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        //alert(json.msj);
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Algo salio super mal!',
            footer: '<a href>Tienes algun problema?</a>'
        });


    });
}
