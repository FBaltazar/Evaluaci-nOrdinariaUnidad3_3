$(document).ready(
        function () {
            $('#tbAdmin').DataTable(
                    {
                        "ajax": "ConsultaAdmin",

                        "columns": [//Atributos que se pondrán en cada columna
                            {"data": "id"},
                            {"data": "nombre"},
                            {"data": "correo"},
                            {"data": "contrasena"},
                            {"data": "roll"},

                            {"data":
                                        function (row) {
                                            var r = row['id'] + "-" + row['nombre'] + "-" + row['correo'] + "-" + row['contrasena'] + "-" + row['roll']; //Acceder
                                            console.log('valor de r' + r);
                                            var botones = "<button id='btnBorrar' class='btn btn-primary btn-xs' onClick='deleteAdmin(" + row['id'] + ")'>Borrar</button>";
                                            botones += "<button id='btnEditar' class='btn btn-xs btn-danger' onClick='showAdmin(" + row['id'] + ",\"" + row['nombre']+ "\")'>Editar</button>";
                                            return botones;
                                        }
                            }
                        ]
                    });


            //valida los campos
            $('#frmAdmin').validate({
                rules: {
                    nombre: {
                        required: true
                    },
                    correo: {
                        required: true
                    },
                    contrasena: {
                        required: true
                    },
                    roll: {
                        required: true
                    }
                    
                },
                messages: {
                    nombre: {
                        required: "El nombre del rol es requerido"
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error');
                },
                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function (error, element) {
                    if (element.parent('.input-group'.length)) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element)
                    }
                },
                submitHandler: function (form) {
                    console.log('Formulario válido');
                    nuevoAdmin();
                    return false;
                }
            });

            //validar forma modal
            $('#frmAdmin2').validate({
                rules: {

                    nombre2: {
                        required: true
                    },
                    correo2: {
                        required: true
                    },
                    contrasena2: {
                        required: true
                    },
                    roll2: {
                        required: true
                    }
                    
                },
                messages: {
                    nombre: {
                        required: "El nombre del rol es requerido"
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error');
                },
                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function (error, element) {
                    if (element.parent('.input-group'.length)) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element)
                    }
                },
                submitHandler: function (form) {
                    console.log('Formulario modal válido');
                    updateAdmin();
                    return false;
                }


            });

            //cuando apareza mi showmodal guardar datos en la bd
            $('#btnEditar').on('click', function () {
                $('#frmAdmin2').submit();
            });

        }); // que se ejecute ya que esté listo
//FUNCIONES DEL CRUD
function deleteAdmin(id) {

    //Utilizando Ajax para realizar una petición al servlet que elimina personas
    $.ajax({
        url: "EliminaAdmin", //Url del Servlet
        type: "POST", //Método HTTP por el que se hace la petición
        data: {//Es la información que mando al servlet
            id: id
        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        Swal.fire(
                'Tu operación',
                'a sido exitosa',
                'Sigue en acción'
                );


        //Refrescando la tabla
        $('#tbAdmin').dataTable().api().ajax.reload();
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        Swal.fire('Algo salio Muy Mal ');

        //alert("error");
    });
}



//
function nuevoAdmin() {
    $.ajax({
        url: 'NuevoAdmin',
        type: 'POST',
        data: {
            id: $("#id").val(),
            nombre: $("#nombre").val(),
            correo: $("#correo").val(),
            contrasena: $("#contrasena").val(),
            roll: $("#roll").val()

        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        //alert(json.msj);
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Todo va muy bien',
            showConfirmButton: false,
            timer: 1500
        });
        //Refrescando la tabla
        $('#tbAdmin').dataTable().api().ajax.reload();
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Por alguna extraña razon algo salio muy mal!',
            footer: '<a href>Why do I have this issue?</a>'
        });
    });


}

function showAdmin(id, nombre,correo,contrasena,roll) {
    $("#id2").val(id);
    $("#nombre2").val(nombre);
    $("#correo2").val(correo);
    $("#contrasena2").val(contrasena);
    $("#roll2").val(roll);
    $("#modalAdmin").modal("show");

}

function updateAdmin() {
    $.ajax({
        url: 'ActualizaAdmin',
        type: 'POST',
        data: {
            id: $("#id2").val(),
            nombre: $("#nombre2").val(),
            correo: $("#correo2").val(),
            contrasena: $("#contrasena2").val(),
            roll: $("#roll2").val()

        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        //alert(json.msj);
        Swal.fire({
            title: 'Operación exitosa',
            width: 600,
            padding: '3em',
            background: '#fff url(/images/trees.png)',
            backdrop: `
                          rgba(0,0,123,0.4)
                          url("/images/nyan-cat.gif")
                          center left
                          no-repeat
                        `
        })
        //Refrescando la tabla
        $('#tbAdmin').dataTable().api().ajax.reload();

        //Cerrando el modal
        $('#modalAdmin').modal("toggle");
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        //alert(json.msj);
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Algo salio super mal!',
            footer: '<a href>Tienes algun problema?</a>'
        });


    });
}
