$(document).ready(
        function () {
            $('#tbTarjeta').DataTable(
                    {
                        "ajax": "ConsultaTarjeta",

                        "columns": [//Atributos que se pondrán en cada columna
                            {"data": "id"},
                            {"data": "numeracion"},
                            {"data": "fechacaducidad"},
                            {"data": "numseguridad"},
                            {"data": "pais"},
                            {"data": "codigopostal"},
                            {"data":
                                        function (row) {
                                            var r = row['id'] + "-" + row['numeracion'] + "-" + row['fechacaducidad'] + "-" + row['numseguridad'] + "-" + row['pais']+"-"+row['codigopostal']; //Acceder
                                            console.log('valor de r' + r);
                                            var botones = "<button id='btnBorrar' class='btn btn-primary btn-xs' onClick='deleteTarjeta(" + row['id'] + ")'>Borrar</button>";
                                            botones += "<button id='btnEditar' class='btn btn-xs btn-danger' onClick='showTarjeta(" + row['id'] + ",\"" + row['numeracion']+ "\")'>Editar</button>";
                                            return botones;
                                        }
                            }
                        ]
                    });


            //valida los campos
            $('#frmTarjeta').validate({
                rules: {
                    numeracion: {
                        required: true
                    },
                    fechacaducidad: {
                        required: true
                    },
                    numseguridad: {
                        required: true
                    },
                    pais: {
                        required: true
                    },
                    codigopostal: {
                        required: true
                    }
                    
                },
                messages: {
                    numeracion: {
                        required: "El numeracion del rol es requerido"
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error');
                },
                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function (error, element) {
                    if (element.parent('.input-group'.length)) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element)
                    }
                },
                submitHandler: function (form) {
                    console.log('Formulario válido');
                    nuevoTarjeta();
                    return false;
                }
            });

            //validar forma modal
            $('#frmTarjeta2').validate({
                rules: {

                    numeracion2: {
                        required: true
                    },
                    fechacaducidad2: {
                        required: true
                    },
                    numseguridad2: {
                        required: true
                    },
                    pais2: {
                        required: true
                    },
                    codigopostal2: {
                        required: true
                    }
                    
                },
                messages: {
                    numeracion: {
                        required: "El numeracion del rol es requerido"
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error');
                },
                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function (error, element) {
                    if (element.parent('.input-group'.length)) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element)
                    }
                },
                submitHandler: function (form) {
                    console.log('Formulario modal válido');
                    updateTarjeta();
                    return false;
                }


            });

            //cuando apareza mi showmodal guardar datos en la bd
            $('#btnEditar').on('click', function () {
                $('#frmTarjeta2').submit();
            });

        }); // que se ejecute ya que esté listo
//FUNCIONES DEL CRUD
function deleteTarjeta(id) {

    //Utilizando Ajax para realizar una petición al servlet que elimina personas
    $.ajax({
        url: "EliminaTarjeta", //Url del Servlet
        type: "POST", //Método HTTP por el que se hace la petición
        data: {//Es la información que mando al servlet
            id: id
        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        Swal.fire(
                'Tu operación',
                'a sido exitosa',
                'Sigue en acción'
                );


        //Refrescando la tabla
        $('#tbTarjeta').dataTable().api().ajax.reload();
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        Swal.fire('Algo salio Muy Mal ');

        //alert("error");
    });
}



//
function nuevoTarjeta() {
    $.ajax({
        url: 'NuevoTarjeta',
        type: 'POST',
        data: {
            idrol: $("#id").val(),
            numeracion: $("#numeracion").val(),
            fechacaducidad: $("#fechacaducidad").val(),
            numseguridad: $("#numseguridad").val(),
            pais: $("#pais").val(),
            codigopostal: $("#codigopostal").val()

        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        //alert(json.msj);
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Todo va muy bien',
            showConfirmButton: false,
            timer: 1500
        });
        //Refrescando la tabla
        $('#tbTarjeta').dataTable().api().ajax.reload();
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Por alguna extraña razon algo salio muy mal!',
            footer: '<a href>Why do I have this issue?</a>'
        });
    });


}

function showTarjeta(id, numeracion,fechacaducidad,numseguridad,pais,codigopostal) {
    $("#id2").val(id);
    $("#numeracion2").val(numeracion);
    $("#fechacaducidad2").val(fechacaducidad);
    $("#numseguridad2").val(numseguridad);
    $("#pais2").val(pais);
    $("#codigopostal2").val(codigopostal);
    $("#modalTarjeta").modal("show");

}

function updateTarjeta() {
    $.ajax({
        url: 'ActualizaTarjeta',
        type: 'POST',
        data: {
            id: $("#id2").val(),
            numeracion: $("#numeracion2").val(),
            fechacaducidad: $("#fechacaducidad2").val(),
            numseguridad: $("#numseguridad2").val(),
            pais: $("#pais2").val(),
            codigopostal: $("#codigopostal2").val()

        }
    }).done(function (json) { //Se ejecuta cuando todo sale bien
        //alert(json.msj);
        Swal.fire({
            title: 'Operación exitosa',
            width: 600,
            padding: '3em',
            background: '#fff url(/images/trees.png)',
            backdrop: `
                          rgba(0,0,123,0.4)
                          url("/images/nyan-cat.gif")
                          center left
                          no-repeat
                        `
        })
        //Refrescando la tabla
        $('#tbTarjeta').dataTable().api().ajax.reload();

        //Cerrando el modal
        $('#modalTarjeta').modal("toggle");
    }).fail(function (json) { //Se ejecuta cuando algo sale mal
        //alert(json.msj);
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Algo salio super mal!',
            footer: '<a href>Tienes algun problema?</a>'
        });


    });
}
