/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.edu.ittepic.ejbs;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import mx.edu.ittepic.entidades.Administrador;
import mx.edu.ittepic.entidades.Servicio;
import mx.edu.ittepic.entidades.Tarjeta;
/**
 *
 * @author anadl
 */
@Stateless
public class EJBOperaciones {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
    @PersistenceContext
    EntityManager em;
    
    public String nuevoAdmin(String nombre,String correo,String contrasena,String roll){
        Administrador admin = new Administrador();
        admin.setNombre(nombre);
        admin.setCorreo(correo);
        admin.setContrasena(contrasena);
        admin.setRoll(roll);
        String msj;
        
        try{
        em.persist(admin);
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch (Exception e){
        msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
    }
        return msj;
    }
    
    public String consultaAdmin(){
        
        try{
            Query q;
            List<Administrador> listaAdmin;
            q=em.createNamedQuery("Administrador.findAll");
            listaAdmin=q.getResultList();
            
            GsonBuilder builder = new GsonBuilder();
            Gson gson = builder.create();
            
            return gson.toJson(listaAdmin);
           
        }catch(Exception e){
            return "{msg:'Error'}";
        } 
    }
    
    public String eliminaAdmin(int id){
        
        Administrador admin = new Administrador();
        String msj;
        
        try{
            admin = (Administrador) em.createNamedQuery("Administrador.findById").setParameter("id",id).getSingleResult();
            em.remove(em.merge(admin));
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch(NumberFormatException e){
             msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
        }
        return msj;
    }
    
    public String actualizaAdmin(int id,String nombre,String correo,String contrasena,String roll){
        GsonBuilder builder= new GsonBuilder();
        Gson gson= builder.create();
        Administrador admin= new Administrador();
        admin.setNombre(nombre);
        admin.setCorreo(correo);
        admin.setContrasena(contrasena);
        admin.setRoll(roll);
        String msj;
        
        try{
            admin= em.find(Administrador.class,id); // buscar por Adminid
            admin.setNombre(nombre);
            admin.setCorreo(correo);
            admin.setContrasena(contrasena);
            admin.setRoll(roll);
            em.merge(admin);
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch(NumberFormatException e){
           msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
        }
       return msj;
    }
    
    public String nuevoServi(String idioma,String fecha,String comentarios,String insentivo){
        Servicio servi = new Servicio();
        servi.setIdioma(idioma);
        servi.setFecha(fecha);
        servi.setComentarios(comentarios);
        servi.setInsentivo(insentivo);
        String msj;
        
        try{
        em.persist(servi);
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch (Exception e){
        msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
    }
        return msj;
    }
    
    public String consultaServi(){
        
        try{
            Query q;
            List<Servicio> listaServi;
            q=em.createNamedQuery("Servicio.findAll");
            listaServi=q.getResultList();
            
            GsonBuilder builder = new GsonBuilder();
            Gson gson = builder.create();
            
            return gson.toJson(listaServi);
           
        }catch(Exception e){
            return "{msg:'Error'}";
        } 
    }
    
    public String eliminaServi(int id){
        
        Servicio servi = new Servicio();
        String msj;
        
        try{
            servi = (Servicio) em.createNamedQuery("Servicio.findById").setParameter("id",id).getSingleResult();
            em.remove(em.merge(servi));
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch(NumberFormatException e){
             msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
        }
        return msj;
    }
    
    public String actualizaServi(int id,String idioma,String fecha,String comentarios,String insentivo){
        GsonBuilder builder= new GsonBuilder();
        Gson gson= builder.create();
        Servicio servi= new Servicio();
        servi.setIdioma(idioma);
        servi.setFecha(fecha);
        servi.setComentarios(comentarios);
        servi.setInsentivo(insentivo);
        String msj;
        
        try{
            servi= em.find(Servicio.class,id); // buscar por Adminid
            servi.setIdioma(idioma);
            servi.setFecha(fecha);
            servi.setComentarios(comentarios);
            servi.setInsentivo(insentivo);
            em.merge(servi);
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch(NumberFormatException e){
           msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
        }
       return msj;
    }
      
    
    
    public String nuevoTarjeta(String numeracion,String fechacaducidad,String numseguridad,String pais,String codigopostal){
        Tarjeta tarjeta = new Tarjeta();
        tarjeta.setNumeracion(numeracion);
        tarjeta.setNumseguridad(numseguridad);
        tarjeta.setPais(pais);
        tarjeta.setCodigopostal(codigopostal);
        String msj;
        
        try{
        em.persist(tarjeta);
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch (Exception e){
        msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
    }
        return msj;
    }
    
    public String consultaTarjeta(){
        
        try{
            Query q;
            List<Tarjeta> listaTarjeta;
            q=em.createNamedQuery("Tarjeta.findAll");
            listaTarjeta=q.getResultList();
            
            GsonBuilder builder = new GsonBuilder();
            Gson gson = builder.create();
            
            return gson.toJson(listaTarjeta);
           
        }catch(Exception e){
            return "{msg:'Error'}";
        } 
    }
    
    public String actualizaTarjeta(int id,String numeracion,String fechacaducidad,String numseguridad,String pais,String codigopostal){
        GsonBuilder builder= new GsonBuilder();
        Gson gson= builder.create();
        Tarjeta tarjeta= new Tarjeta();
        tarjeta.setNumeracion(numeracion);
        tarjeta.setFechacaducidad(fechacaducidad);
        tarjeta.setNumseguridad(numseguridad);
        tarjeta.setPais(pais);
        tarjeta.setCodigopostal(codigopostal);
        String msj;
        
        try{
            tarjeta= em.find(Tarjeta.class,id); // buscar por Adminid
            tarjeta.setNumeracion(numeracion);
            tarjeta.setFechacaducidad(fechacaducidad);
            tarjeta.setNumseguridad(numseguridad);
            tarjeta.setPais(pais);
            tarjeta.setCodigopostal(codigopostal);
            em.merge(tarjeta);
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch(NumberFormatException e){
           msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
        }
       return msj;
    }
    
    public String eliminaTarjeta(int id){
        
        Tarjeta tarjeta = new Tarjeta();
        String msj;
        
        try{
            tarjeta = (Tarjeta) em.createNamedQuery("Tarjeta.findById").setParameter("id",id).getSingleResult();
            em.remove(em.merge(tarjeta));
            msj="{\"code\":200, \"msj\":\"la operacion se realizo correctamente\"}";
        }catch(NumberFormatException e){
             msj="{\"code\":400, \"msj\":\"Error en los tipos de parametros\"}";
        }
        return msj;
    }
}
