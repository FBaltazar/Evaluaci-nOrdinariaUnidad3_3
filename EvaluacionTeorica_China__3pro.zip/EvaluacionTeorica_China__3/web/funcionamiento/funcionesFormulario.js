/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function validarFormulario(forma){
    var usuario=forma.usuario;
    if(usuario.value.length==0){
        alert("Debe proporcionar un nombre de usuario");
        usuario.focus();
        usuario.select();
        return false;
    }
     
    var password=forma.password;
    if(password==""||password.value.length<8){
        alert("Debe proporcionar una contraseña de almenos 8 coracters");
        password.focus();
        password.select();
        return false;
    }
    
    var tecnologias=forma.tecnologias;
    var checkSeleccionado=false;
        for(i=0;i<tecnologias.length;i++){
        if (tecnologias[i].checked){
            checkSeleccionado=true;
        }
    }
    
    if(!checkSeleccionado){
        alert("Seleccione otro país");
        return false;
    }
    
    var genero=forma.genero;
    var seleccionGenero=false;
        for (var i=0;i<genero.length;i++){
        if(genero[i].checked)
            seleccionGenero=true;
            break;
        }
    
    if(!seleccionGenero){
        return false;
    }
    
    var ocupacion=forma.ocupacion;
    if(ocupacion.value==""){
        alert("Debera seleccionar una ocupación");
        ocupacion.focus();
        ocupacion.select();
        return true;
    }
    alert("Enviando formulario...");
    return true;
}
