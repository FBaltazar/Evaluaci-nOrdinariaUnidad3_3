/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.edu.ittepic.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author anadl
 */
@Entity
@Table(name = "tarjeta")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tarjeta.findAll", query = "SELECT t FROM Tarjeta t")
    , @NamedQuery(name = "Tarjeta.findById", query = "SELECT t FROM Tarjeta t WHERE t.id = :id")
    , @NamedQuery(name = "Tarjeta.findByNumeracion", query = "SELECT t FROM Tarjeta t WHERE t.numeracion = :numeracion")
    , @NamedQuery(name = "Tarjeta.findByFechacaducidad", query = "SELECT t FROM Tarjeta t WHERE t.fechacaducidad = :fechacaducidad")
    , @NamedQuery(name = "Tarjeta.findByNumseguridad", query = "SELECT t FROM Tarjeta t WHERE t.numseguridad = :numseguridad")
    , @NamedQuery(name = "Tarjeta.findByPais", query = "SELECT t FROM Tarjeta t WHERE t.pais = :pais")
    , @NamedQuery(name = "Tarjeta.findByCodigopostal", query = "SELECT t FROM Tarjeta t WHERE t.codigopostal = :codigopostal")})
public class Tarjeta implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "numeracion")
    private String numeracion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "fechacaducidad")
    private String fechacaducidad;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "numseguridad")
    private String numseguridad;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "pais")
    private String pais;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "codigopostal")
    private String codigopostal;

    public Tarjeta() {
    }

    public Tarjeta(Integer id) {
        this.id = id;
    }

    public Tarjeta(Integer id, String numeracion, String fechacaducidad, String numseguridad, String pais, String codigopostal) {
        this.id = id;
        this.numeracion = numeracion;
        this.fechacaducidad = fechacaducidad;
        this.numseguridad = numseguridad;
        this.pais = pais;
        this.codigopostal = codigopostal;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNumeracion() {
        return numeracion;
    }

    public void setNumeracion(String numeracion) {
        this.numeracion = numeracion;
    }

    public String getFechacaducidad() {
        return fechacaducidad;
    }

    public void setFechacaducidad(String fechacaducidad) {
        this.fechacaducidad = fechacaducidad;
    }

    public String getNumseguridad() {
        return numseguridad;
    }

    public void setNumseguridad(String numseguridad) {
        this.numseguridad = numseguridad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCodigopostal() {
        return codigopostal;
    }

    public void setCodigopostal(String codigopostal) {
        this.codigopostal = codigopostal;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tarjeta)) {
            return false;
        }
        Tarjeta other = (Tarjeta) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mx.edu.ittepic.entidades.Tarjeta[ id=" + id + " ]";
    }
    
}
